export const chartData = [
  {"time": '월요일',"tem": 10,"city": "beijing"},
  {"time": '화요일',"tem": 22,"city": "beijing"},
  {"time": '수요일',"tem": 20,"city": "beijing"},
  {"time": '목요일',"tem": 26,"city": "beijing"},
  {"time": '금요일',"tem": 20,"city": "beijing"},
  {"time": '토요일',"tem": 26,"city": "beijing"},
  {"time": '일요일',"tem": 28,"city": "beijing"},
  {"time": '월요일',"tem": 5,"city": "newYork"},
  {"time": '화요일',"tem": 12,"city": "newYork"},
  {"time": '수요일',"tem": 26,"city": "newYork"},
  {"time": '목요일',"tem": 20,"city": "newYork"},
  {"time": '금요일',"tem": 28,"city": "newYork"},
  {"time": '토요일',"tem": 26,"city": "newYork"},
  {"time": '일요일',"tem": 20,"city": "newYork"}
];

export const pieData = [{pointer: '当前收益',value: 5, length:2,y:1.05}];

export const barData = [
  {"time":"월요일","tem":6.9,"city":"tokyo"},
  {"time":"화요일","tem":9.5,"city":"tokyo"},
  {"time":"수요일","tem":14.5,"city":"tokyo"},
  {"time":"목요일","tem":18.2,"city":"tokyo"},
  {"time":"금요일","tem":21.5,"city":"tokyo"},
  {"time":"토요일","tem":25.2,"city":"tokyo"},
  {"time":"일요일","tem":26.5,"city":"tokyo"},
  {"time":"월요일","tem":0.8,"city":"newYork"},
  {"time":"화요일","tem":5.7,"city":"newYork"},
  {"time":"수요일","tem":11.3,"city":"newYork"},
  {"time":"목요일","tem":17,"city":"newYork"},
  {"time":"금요일","tem":22,"city":"newYork"},
  {"time":"토요일","tem":24.8,"city":"newYork"},
  {"time":"금요일","tem":24.1,"city":"newYork"},
  {"time":"월요일","tem":0.6,"city":"berlin"},
  {"time":"화요일","tem":3.5,"city":"berlin"},
  {"time":"수요일","tem":8.4,"city":"berlin"},
  {"time":"목요일","tem":13.5,"city":"berlin"},
  {"time":"금요일","tem":17,"city":"berlin"},
  {"time":"토요일","tem":18.6,"city":"berlin"},
  {"time":"일요일","tem":17.9,"city":"berlin"}
];
