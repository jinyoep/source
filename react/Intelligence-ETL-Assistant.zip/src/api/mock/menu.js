module.exports = {
    menus: [
      {
        key: 5,
        name: 'Home',
        icon: 'home',
        url: '/home'
      },
      {
        key: 1,
        name: 'Pages',
        icon: 'user',
        child: [
          {
            name: 'Form',
            key: 102,
            url: '/form'
          },
          {
            name: 'Table',
            key: 103,
            url: '/table'
          },
          {
            name: 'Calendar',
            key: 104,
            url: '/calendar'
          },
          {
            name: 'Timeline',
            key: 105,
            url: '/timeline'
          },
          {
            name: 'Steps',
            key: 106,
            url: '/steps'
          }
        ]
      },
      {
        key: 2,
        name: 'ETL Manager',
        icon: 'laptop',
        child: [
          {
            name: '작업대시보드',
            key: 201,
            url: '/dash-board'
          },
          {
            name: '작업현황',
            key: 202,
            url: '/job-status'
          },
          {
            name: '작업리스트',
            key: 203,
            url: '/job-list'
          },
          {
            name: '소급작업관리',
            key: 204,
            url: '/job-exec-management'
          },
          {
            name: '소급작업상세',
            key: 205,
            url: '/fail'
          },
          {
            name: '소급작업상세',
            key: 206,
            url: '/fail'
          },
          {
            name: '공통그룹관리',
            key: 207,
            url: '/group-code-management'
          },
          {
            name: '작업관리',
            key: 209,
            url: '/job-management'
          },
          {
            name: 'Job context관리',
            key: 211,
            url: '/job-context-management'
          },
          {
            name: '작업출력',
            key: 212,
            url: '/job-report'
          }
        ]
      }
    ]
  }
